These programs have been written by Gaurav Gupta and are shared under the Creative Commons License.
